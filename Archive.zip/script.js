//!DOM Selected Variable
const lists = document.querySelectorAll(`.navList`);
const listContainer = document.querySelector(`.navLists`);
const navHome = document.querySelector(`.homeNav`);
const toggleMenu = document.querySelector(`.toggle-menu`);
const menu = document.querySelector(`.menu`);
const closeToogle = document.querySelector(`.close`);
const shopContainer = document.querySelector(`.shop-container`);
//////////////////////////////////////////////
//!Variables
const protocol = window.location.protocol;
const host = window.location.host;
const filePath = window.location.pathname;
const shopAddress = `${protocol}//${host}/pages/shop.html`;
const cartAddress = `${protocol}//${host}/pages/cart.html`;
console.log(protocol);
////! Nav And Toogle Menu Start! ////

//!Change localStorage value with Web URL
function unknow(address) {
  if (shopAddress === address) localStorage.setItem("id", 2);
  else if (cartAddress === address) localStorage.setItem("id", 3);
  else {
    localStorage.setItem("id", 1);
  }
}
unknow(window.location.href);
///////////////////////////////////////////

//!EventListener for NAV
listContainer.addEventListener(`click`, function (e) {
  // e.preventDefault();
  const item = e.target.closest(`.navList`);

  if (!item) return;
  lists.forEach((list) => {
    list.classList.remove(`actived`);
  });

  item.classList.add(`actived`);
  //!Change localStorage value with data attribute
  localStorage.setItem("id", item.dataset.id);
});
navHome.addEventListener(`click`, function () {
  lists.forEach((list) => {
    list.classList.remove(`actived`);
  });
  localStorage.setItem(`id`, 1);
});
//! NAV Hover Effect
lists.forEach((list) => {
  list.addEventListener(`mouseover`, function () {
    this.classList.add(`hovered`);
  });
  list.addEventListener(`mouseout`, function () {
    this.classList.remove(`hovered`);
  });
});
/////////////////////////////////////////////////////////

//! Add a class base on localStorage value
const getId = JSON.parse(localStorage.getItem("id"));
lists.forEach((list) => {
  if (list.dataset.id == getId) {
    list.classList.add(`actived`);
  }
});
//////////////////////////////////////////////////////////
//! Rendering side menu for smaller screen
menu.addEventListener(`click`, function (e) {
  toggleMenu.classList.add(`toggle-menu-open`);
});
closeToogle.addEventListener(`click`, function () {
  toggleMenu.classList.remove(`toggle-menu-open`);
});
document.querySelector(`section`).addEventListener(`click`, function (e) {
  toggleMenu.classList.remove(`toggle-menu-open`);
});

////! Nav And Toogle Menu END! ////

////! Shop Page Start Here!////

class Item {
  constructor() {
    this.#itemList();
    this.#showItem();
  }
  #itemList() {
    this.items = [
      { id: 1, name: `T-Shirt`, price: 20, img: `/img/t1.png` },
      { id: 2, name: `Jean`, price: 30, img: `/img/t2.png` },
      { id: 3, name: `Jacket`, price: 50, img: `/img/t3.png` },
    ];
  }
  #showItem() {
    if (!shopContainer) return;
    this.items.forEach((item) => {
      const html = `<div class="item-contents" data-id="${item.id}">
        <div><img src="${item.img}" alt="" /></div>
        <div class="item-details">
          <div>
            <h3>${item.name}</h3>
            <p>$${item.price}</p>
          </div>
          <button class="btnToCart">Add to cart</button>
        </div>
      </div>`;
      shopContainer.insertAdjacentHTML(`beforeend`, html);
    });
  }
}
const itemManager = new Item();
